package com.company;

public class BinaryTreeNode {

    int key;
    BinaryTreeNode left, right;

    public BinaryTreeNode(int key) {
        this.key = key;
        left = null;
        right = null;
    }

}
