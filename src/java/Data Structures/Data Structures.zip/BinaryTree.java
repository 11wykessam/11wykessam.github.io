package com.company;

public class BinaryTree {

    BinaryTreeNode root;

    public BinaryTree(int key) {
        root = new BinaryTreeNode(key);
    }

    public void printInfix(BinaryTreeNode node) {
        if(node != null) {
            printInfix(node.left);
            System.out.println(node.key);
            printInfix(node.right);
        }
    }

    public void printPostfix(BinaryTreeNode node) {
        if(node != null) {
            printPostfix(node.left);
            printPostfix(node.right);
            System.out.println(node.key);
        }
    }

    public void printPrefix(BinaryTreeNode node) {
        if (node != null) {
            System.out.println(node.key);
            printPrefix(node.left);
            printPrefix(node.right);
        }
    }


}
